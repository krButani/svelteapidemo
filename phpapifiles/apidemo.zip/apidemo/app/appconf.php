<?php 
	
	Class AppConf {
		var $general = array(
								"sitename" => "API Demo",
								"company" => "API Demo",
								"appurl" => "http://localhost/apidemo",
						    );

		var $db = array(
							"server"=>"localhost",
							"username"=>"root",
							"password"=>"",
							"database"=>"apidemo",
						);

		var $isHtmlMinfiy = false;

		
		/* 
			Give Full Path of Files

			if your dir stucure is following and load first.php 
			* app
			* views/header/first.php
			* index.php

			Than give path like following:
			'views/header/first.php'
		*/


		var $preloadfiles = array(
									//'app/custom/Appfunc.php',
								 );

       /*  var $custload = array(
            'api' => [
                'app/custom/Api.php'
            ]
        ); */

	}

	

?>