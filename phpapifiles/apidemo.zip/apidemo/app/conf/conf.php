<?php

    date_default_timezone_set("Asia/kolkata");
	if(!isset($_SESSION))
		session_start();

	$commondir =  str_replace('\\','/',__dir__).'/';

	$commondir = str_replace("app/conf/",'',$commondir);
	
	set_include_path($commondir); 

	require_once('app/appconf.php');
	
	$app = new AppConf();

	require_once('app/lib/ob-start.php');
	
	if(!(!isset($app->general) && !isset($app->general['appurl']) && empty($app->general['appurl'])))
		define("APPURL",$app->general['appurl']);
	else
		die('ERROR[KLP001]: App Url is not define');

	$loadfiles = [
					'app/lib/database.php',
				  	'app/lib/functions.php'
				];

    if(isset($g['loadclass']) && isset($app->registerClass)) {
        foreach($g['loadclass'] as $key => $value) {
            if(isset($app->registerClass[$value])) {
                array_push($loadfiles,$app->registerClass[$value]);
            }
        }

    }
    
    $loadfiles = array_merge($loadfiles,$app->preloadfiles);

	foreach ($loadfiles as $key => $value) {
		require_once $value;
	}

	unset($loadfiles);

?>