<?php 

  	$mt = array();
  	if(isset($isMeta) && $isMeta == true) {
  		$mt = getPageMeta();
  	}


  	if(is_array($mt) && count($mt) > 0) {
?>	
	<?php if(isset($mt['title'])): ?>
	<meta name="title" content="<?php echo $mt['title']; ?>">
	<?php endif; ?>
	<meta name="descriptioniption" content="<?php echo $mt['description']; ?>">
	<meta property="og:locale" content="en_US" />
	<meta property="og:url" content="<?php echo $mt['url']; ?>" />
	<meta property="og:type" content="product" />
	<?php if(isset($mt['title'])): ?>
	<meta property="og:title" content="<?php echo $mt['title']; ?>" />
	<?php endif; ?>
	<meta property="og:site_name" content="Shatavdhani" />
	<meta property="og:descriptioniption" content="<?php echo $mt['description']; ?>" />
	<?php if(isset($mt['photo']) && file_exists($mt['photo'])): ?>
	<meta property="og:image" content="<?php echo $baseurl.$mt['photo']; ?>" />
	<?php list($width, $height, $type, $attr) = getimagesize($baseurl.$mt['photo']); ?>
	<meta property="og:image:width" content="<?php echo $width; ?>" />
	<meta property="og:image:height" content="<?php echo $height; ?>" />
	<?php 
		unset($width,$height,$type,$attr);
		endif; 
	?>
	<meta property="og:upublish_dated_time" content="<?php echo date(DATE_W3C,strtotime($mt['publish_date'])); ?>" />
	<?php if(isset($mt['keywords'])): ?>
	<meta property="article:tag" content="<?php echo $mt['keywords']; ?>" /> 
	<?php endif; ?>
	<meta property="article:section" content="Social And Cultural" />
	<?php if(isset($mt['publish_date'])): ?>
	<meta property="article:published_time" content="<?php echo date(DATE_W3C,strtotime($mt['publish_date'])); ?>" />
	<?php endif; ?>
	<?php if(isset($mt['modified_date']) || isset($mt['publish_date'])): ?>
	<meta property="article:modified_time" content="<?php if(isset($mt['modified_date'])) echo date(DATE_W3C,strtotime($mt['modified_date'])); else  echo date(DATE_W3C,strtotime($mt['publish_date'])); ?>" />
	<?php endif; ?>
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:site" content="<?php echo $mt['url']; ?>" />
	<?php if(isset($mt['title'])): ?>
	<meta name="twitter:title" content="<?php echo $mt['title']; ?>" />
	<?php endif; ?>
	<meta name="twitter:descriptioniption" content="<?php echo $mt['description']; ?>" />
	<?php if(isset($mt['photo']) && file_exists($mt['photo'])): ?>
	<meta name="twitter:image" content="<?php echo $baseurl.$mt['photo']; ?>" />
	<?php endif; ?>
	<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
	<meta itemscope itemtype="<?php echo $mt['url']; ?>" />
	<?php if(isset($mt['title'])): ?>
	<meta itemprop="headline" content="<?php echo $mt['title']; ?>" />
	<?php endif; ?>
	<meta itemprop="descriptioniption" content="<?php echo $mt['description']; ?>" />
	<?php if(isset($mt['photo']) && file_exists($mt['photo'])): ?>
	<meta itemprop="image" content="<?php echo $baseurl.$mt['photo']; ?>" />
	<?php endif; ?>
	
<?php
  	}

?>