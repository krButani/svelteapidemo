<?php 

	Class DirFunc {

		function remove_http($url) {


			$disallowed = array('http://', 'https://');
			foreach($disallowed as $d) {
			  if(strpos($url, $d) === 0) {
			     $url = str_replace($d, '', $url);
			  }
			}
			
			$url = explode("/",rtrim($url,"/"));
			array_shift($url);
			$url = $url[count($url)-1];

			return $url;
		}
	}

	$dirfunc = new DirFunc();

?>