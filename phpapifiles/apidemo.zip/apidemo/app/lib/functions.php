<?php 


class krLitePhpFunc {

	function __construct() {
		register_shutdown_function(array(&$this, 'goodbye')); 
	}

	function compress_image($source_url, $destination_url, $quality = 40) {
        $upload = false;
        $info = getimagesize($source_url);
        if ($info['mime'] == 'image/jpeg') {
            $image = imagecreatefromjpeg($source_url);
            imagejpeg($image, $destination_url, $quality);
            $upload = true;
        } else if(move_uploaded_file($source_url, $destination_url)) {
            $upload = true;
        }
		return $upload;
	}	

	function upload_file($tempfile,$desfile) {
	
		if(move_uploaded_file($tempfile, $desfile)) {		
			return true;
		} else {
			return false;
		}
	
	}


	function goodbye()
	{

		$arr = array('submitFromGatu','viewFromGatu');

		foreach ($arr as $key => $value) {
			if(function_exists($value)) {
				$value();
			}
		}
		

	    // This is our shutdown function, in 
	    // here we can do any last operations
	    // before the script is complete.
		unset($GLOBALS['commondir'],$GLOBALS['app'],$GLOBALS['db']);
	   	
		ob_end_flush();
	    // echo '<br>Script executed with success', PHP_EOL;
	}

	function printcssurl($urlarr) {
		foreach ($urlarr as $key => $value) {
           echo '<link rel="stylesheet" type="text/css" href="'.$value.'">';
		}
	}


	function printassetscss($urlarr) {
		foreach ($urlarr as $key => $value) {
           echo '<link rel="stylesheet" type="text/css" href="'.APPURL.$value.'">';
		}
	}

	function printjsurl($urlarr) {
		foreach ($urlarr as $key => $value) {
            echo '<script src="'.$value.'" type="text/javascript"></script>';
		}
	}

	function printassetsjs($urlarr) {
		foreach ($urlarr as $key => $value) {
            echo '<script src="'.APPURL.$value.'" type="text/javascript"></script>';
		}
	}

    function printassetsjsModule($urlarr) {
        foreach ($urlarr as $key => $value) {
            echo '<script src="'.APPURL.$value.'" type="module"></script>';
        }
    }

    function requiredtoload($who) {
        global $app;
        if(isset($app->custload[$who])) {
            if(is_array($app->custload[$who])) {
                foreach ($app->custload[$who] as $key => $value) {
                    require_once($value);
                }
            } else {
                require_once($app->custload[$who]);
            }
        }

    }

	// this function called end of the scripts
}

$func = new krLitePhpFunc();

#############################################################################
# Regular Need Function 
#############################################################################

function required($name) {
	switch($name){
		case "Meta":
			require_once('app/lib/meta.php'); 
			break;

	}
}

function appurl($isPrint = false) {
	if($isPrint == true)
		echo APPURL;
	return APPURL;
}

function e($string) {
 	$arr = array(PASSWORD_DEFAULT,PASSWORD_BCRYPT,PASSWORD_ARGON2I);
 	$who = $arr[rand(0,2)];
 	if(isset($who) && !empty($who)) $who = PASSWORD_BCRYPT;
	return password_hash(md5($string),$who);
}

function d($string,$hash) {
  return password_verify(md5($string),$hash);
}


function getLdate($user = false) {
    if($user == false) {
        return date('Y-m-d H:i:s');
    } else {
        return date('d-m-Y');
    }
}

?>