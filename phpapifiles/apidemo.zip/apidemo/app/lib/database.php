<?php

/*
	
Constrator Create DB Connection and it paratmeter
1. Servername
2. Username
3. Password
4. Database

getCon() -> it return connection object;

close()
it close connection
Paramerter:
1. Connection Object [Optional]

count($qry, $isnumrow = false) 
count record

Parameter:
1. Query
2. if false means fetch_row()[0] use and true means num_rows use ( default false )

Response 
array("status"=>0,"msg"=>"","count"=>"0");


selectSingle($qry)
get single record return fetch_assoc result

Parameter: 
1. Query

Response
array("status"=>0,"row"=>"","msg"=>"");



select($qry)
get query result object that can use and fetch record manullay.

Paratmeter
1. Query

Response
array("status"=>0,"result"=>"","msg"=>"");



insert($qry, $ismulti = false) 
Insert Record

Parameter
1. Query
2. if false then insert single record and its true insert multi record

Response
array("status"=>0,"msg"=>"","lastid"=>array());



update($qry)
Update Record

Parameter 
1. Query

Response
array("status"=>1, "msg"=>"");




delete($qry)
Delete Record

Parameter
1. Query

Response
array("status"=>1, "msg"=>"");

*/

class DB {
	private $conn;

	private $servername;
	private $username;
	private $password;
	private $dbname;
	private $debug;

	private $dberr = 'Database Connection Failed. Please Try Again.';

	function __construct($server = "localhost", $user = "root", $pass = "", $db = "",$debug = false) {
		$this->servername = $server;
		$this->username = $user;
		$this->password = $pass;
		$this->dbname = $db;
		$this->debug = $debug;
		$this->connect();
	}
	function setDebug($debug = false) {
		$this->debug=$debug;
	}
	function connect() {

		$return = false;

		try {
			$this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
			
			if ($this->conn->connect_error) {
			  		die("Error [KLDBC01]: DB Connection failed: " . $this->conn->connect_error);
			} else {
				$this->conn->set_charset("utf8");
				$return = true;
			}
		} catch(Exception $e) {
		  die('Error [KLDBC02]: Database Connection Error');
		}

		return $return;
	}

	function getCon() {
		return $this->conn;
	}

	function close($conn = "") {
		try {
			if(!empty($conn)) {
				$conn->close();
			} else {
				$this->conn->close();
			}
		} catch(Exception $e) {
			die('Error[KLDBC55]:Connection is not closed.');
		}
	}

	function count($qry, $isnumrow = false) {

		$return = array("status"=>0,"msg"=>"","count"=>"0","record"=>"");

		if(!empty($qry)) {
			try {
				$result = $this->conn->query($qry);

				$count = "";

				if(!empty($result)) {

					if($isnumrow == false) {
						$row = $result->fetch_row();
						$count = (isset($row) && $row!= null)?$row[0]:0;
					} else {
						$count = $result->num_rows;
						$return['record'] =  $result->fetch_row();
					}

					if($count != "")  {
						$return['status'] = 1;
						$return['msg'] = "Record get Successfully.";
						$return['count'] = $count;
					} else {
						if($this->debug == true) {
							$return['msg'] = $this->conn->error; 
						} else {
							$return['msg'] = "Query Error.";	
						}
					}
				} else {
					$return['msg'] = "Query Error.";	
				}
			} catch(Exception $e) {
				if($this->debug == true) {
					$return['msg'] = $e->getMessage();
				} else {
					$return['msg'] = "Query Error.";		
				}	
			}

		} else {
			$return['status'] = 2;
			$return['msg'] = "Query is must required.";
		}	

		return $return;

	}

	// order by first then limit
	function selectSingle($qry) {

		$return = array("status"=>0,"row"=>"","msg"=>"");
		if(!empty($qry)) {
			try {
				$result = $this->conn->query($qry);

				if(!empty($result)) {
					if($result->num_rows > 0) {
						$return["status"] = 1;
						$return["row"] = $result->fetch_assoc();
					} else {
						if($this->debug == true) {
							$return['msg'] = $this->conn->error; 
						} else {
							$return['msg'] = "Data is not found.";
						}
					}
				} else {
					$return['msg'] = "Query Error.";
				}
			} catch(Exception $e) {
				if($this->debug == true) {
					$return['msg'] = $e->getMessage();
				} else {
					$return['msg'] = "Query Error.";		
				}	
			}
		} else {
			$return['status'] = 2;
			$return['msg'] = "Query is must required.";
		}	

		return $return;

	}

	function select($qry) {
		$return = array("status"=>0,"result"=>"","msg"=>"");

		if(!empty($qry)) {
			try {
				$result = $this->conn->query($qry);
				
				if(!empty($result)) {
					if($result->num_rows > 0) {
						$result = $this->conn->query($qry);
						$return['status']=1;
						$return['result']=$result;
					} else {
						if($this->debug == true) {
							$return['msg'] = $this->conn->error; 
						} else {
							$return['msg'] = "Data is not found.";
						}
					}
				} else {
					$return['msg'] = "Query Error.";	
				}
			} catch(Exception $e) {
			  	if($this->debug == true) {
					$return['msg'] = $e->getMessage();
				} else {
					$return['msg'] = "Query Error.";		
				}
			}
		} else {
			$return['status'] = 2;
			$return['msg'] = "Query is must required.";
		}


		return $return;
	}

	function insert($qry, $ismulti = false) {
		$return = array("status"=>0,"msg"=>"","lastid"=>array());
		if(!empty($qry)) {
			try {
				if($ismulti == true) {
					$result = $this->conn->multi_query($qry);
				} else {
					$result = $this->conn->query($qry);
				}
				
				if($this->conn->affected_rows > 0) {
				
					$return['status'] = 1;
					$return['msg'] = "Record Inserted Successfully.";

					if($ismulti == true) {
						$ids = array();
						do
						{
					    	$ids[] = $this->conn->insert_id;
					    	if ($this->conn->more_results() === FALSE) break;
						} while($this->conn->next_result());

						$return['lastid'] = $ids;
					
					} else {
						$return['lastid'] = array($this->conn->insert_id);
					}

				} else {
				  if($this->debug == true) {
				  	$return['msg'] = $this->conn->error; 
				  } else {
				  	$return['msg'] = "Record is not inserted";	
				  }
				}
			} catch(Exception $e) {
				if($this->debug == true) {
					$return['msg'] = $e->getMessage();
				} else {
					$return['msg'] = "Query Error.";		
				}
			}
		} else {
			$return['status'] = 2;
			$return['msg'] = "Query is must required.";
		}

		return $return;
	}

	function update($qry) {
		$return = array("status"=>1, "msg"=>"");

		if(!empty($qry)) {
			try {
				$result = $this->conn->query($qry);

				if($this->conn->affected_rows > 0) {
				
					$return['status'] = 1;
					$return['msg'] = "Record Updated Successfully.";

				} else {
					if($this->debug == true) {
						$return['msg'] = $this->conn->error; 
					} else {
						$return['msg'] = "Record is not Updated";	
					}
				}
			} catch(Exception $e) {
				if($this->debug == true) {
					$return['msg'] = $e->getMessage();
				} else {
					$return['msg'] = "Query Error.";		
				}
			}

		} else {
			$return['status'] = 2;
			$return['msg'] = "Query is must required.";	
		}


		return $return;
	}

	function delete($qry) {
		$return = array("status"=>1, "msg"=>"");

		if(!empty($qry)) {
			try {
				$result = $this->conn->query($qry);

				if($this->conn->affected_rows > 0) {
				
					$return['status'] = 1;
					$return['msg'] = "Record Deleted Successfully.";

				} else {
				  if($this->debug == true) {
				  	$return['msg'] = $this->conn->error; 
				  } else {
				  	$return['msg'] = "Record is not Deleted.";	
				  }
				}
			} catch(Exception $e) {
				if($this->debug == true) {
					$return['msg'] = $e->getMessage();
				} else {
					$return['msg'] = "Query Error.";		
				}
			}

		} else {
			$return['status'] = 2;
			$return['msg'] = "Query is must required.";	
		}


		return $return;
	}

	function changeRequest($val) {
		
		$con = $this->conn;
		$return = array();

		foreach ($val as $key => $value) {
			if(is_array($value)) {
				$return[$key] = $this->changeRequest($value);	
			} else {
				$return[$key] = trim($con->real_escape_string($val[$key]));
			}
		}

		return $return;

	}
}

if(isset($app) && isset($app->db) && count($app->db) > 0) {
	if(isset($app) && isset($app->db['server']) && !empty($app->db['server'])) { 
		$server = $app->db['server'];
	} else {
		echo "Error[KLDBC03]: Database Servername is not set";
		die;
	}

	if(isset($app) && isset($app->db['username']) && !empty($app->db['username'])) { 
		$username = $app->db['username'];
	} else {
		echo "Error[KLDBC04]: Database Username is not set";
		die;
	}

	if(isset($app) && isset($app->db['password']) && !empty($app->db['password'])) { 
		$password = $app->db['password'];
	} else {
		$password = "";
	}

	if(isset($app) && isset($app->db['database']) && !empty($app->db['database'])) { 
		$database = $app->db['database'];
	} else {
		echo "Error[KLDBC06]: Database name is not set";
		die;
	}


	$db = new DB($server,$username,$password,$database);
	$db->setDebug(true);

}


?>