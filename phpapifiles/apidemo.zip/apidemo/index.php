<!-- Api Demo -->

<?php 
    require_once 'app/conf/conf.php';
?>

Api Demo is Loaded successfully.