<?php

require_once("../app/conf/conf.php");

$output = array('status' => 0, "data" => "", "error" => array());

$error = array();

if (isset($_POST['token']) && !empty($_POST['token'])) {

    $_POST = $db->changeRequest($_POST);

    extract($_POST);

    if(isset($ref) && !empty($ref)) {

        $qry = "SELECT COUNT(*) FROM student WHERE sid='".$ref."'";

        $res = $db->count($qry);

        if ($res['status'] == 1 && $res['count'] > 0) {
            $qry = "DELETE FROM student WHERE sid='".$ref."'";

            $res = $db->delete($qry);

            if ($res["status"] == 1) {
                $output['data'] = array('msg'=>'Student is deleted successfully.');
                $output['status'] = 1;
            } else {
                $error['error'] = $res["msg"];
            }
        } else {
            $error['error'] = "Id is not found.";
        }

    } else {
        $error['error'] = "Id is invalid.";
    }


} else {
    $error['error'] = "Invalid Authentication.";
}


$output['error'] = $error;


echo json_encode($output);

?>
