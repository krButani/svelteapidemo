<?php

require_once("../app/conf/conf.php");

$output = array('status' => 0, "data" => "", "error" => array());

$error = array();

if (isset($_POST['token']) && !empty($_POST['token'])) {

    $_POST = $db->changeRequest($_POST);

    extract($_POST);

    if (!isset($page))
        $page = 0;

    $record = 10;
    $limit = $record;
    $offset = $limit * $page;

    $qry = "SELECT * FROM student ORDER BY idatetime DESC limit $limit offset $offset";

    $res = $db->select($qry);

    $data = array();
    if ($res["status"] == 1 && $res['result']->num_rows > 0) {

        while ($row = $res['result']->fetch_assoc()) {
            $data[] = $row;
    	}

    }

    $output['data'] = $data;
    $output['status'] = 1;

} else {
    $error['error'] = "Invalid Authentication.";
}


$output['error'] = $error;


echo json_encode($output);

?>
