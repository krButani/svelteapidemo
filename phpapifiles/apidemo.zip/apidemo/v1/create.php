<?php

require_once("../app/conf/conf.php");

$output = array('status' => 0, "data" => "", "error" => array());

$error = array();

if (isset($_POST['token']) && !empty($_POST['token'])) {

    $_POST = $db->changeRequest($_POST);

    extract($_POST);
    
    $status = false;
    if($uname == "")  {
        $error['uname'] = "Name is required.";
        $status = true;
    }

    if($email == "")  {
        $error['email'] = "E-Mail Address is required.";
        $status = true;
    }

    if($mobileno == "")  {
        $error['mobileno'] = "Mobile No. is required.";
        $status = true;
    }

    if($status == false) {

        if(!isset($state))
            $state = "Gujarat";

        if(!isset($city))
            $city = "Bhavnagar";

        $propitc = "";

        if(isset($_FILES["propic"]) && !empty($_FILES["propic"]["name"])) {
            $filepath = "../public/";

            $temp = explode(".", $_FILES["propic"]["name"]);
            $extension = end($temp);

            $filename = date('YmdHis') . rand(100, 999) . "." . $extension;

            $imageTemp = $_FILES["propic"]["tmp_name"];

            if ($func->compress_image($_FILES["propic"]['tmp_name'], $filepath . $filename) == false) {
                $status = true;
                $error['propic'] = 'File is not upload Succefully';
            } else {
                $propitc = $filename;
            }
        }

        $qry = "INSERT INTO `student`(`sname`, `email`, `mobileno`, `state`, `city`, `propic`, `idatetime`) VALUES ('".$uname."','".$email."','".$mobileno."','".$state."','".$city."','".$propitc."','".getLdate()."')";

        $res = $db->insert($qry);

        if ($res["status"] == 1) {
            $lastid = $res['lastid'][0];
            $output['data'] = array('msg'=>"Student Added Successfully.");
            $output['status'] = 1;
        } else {
            $error['msg'] = $res["msg"];
        }
    }

} else {
    $error['msg'] = "Invalid Authentication.";
}


$output['error'] = $error;


echo json_encode($output);

?>
