<?php

require_once("../app/conf/conf.php");

$output = array('status' => 0, "data" => "", "error" => array());

$error = array();

if (isset($_POST['token']) && !empty($_POST['token'])) {

    $_POST = $db->changeRequest($_POST);

    extract($_POST);

    $status = false;
    if($uname == "")  {
        $error['uname'] = "Name is required.";
        $status = true;
    }

    if($email == "")  {
        $error['email'] = "E-Mail Address is required.";
        $status = true;
    }

    if($mobileno == "")  {
        $error['mobileno'] = "Mobile No. is required.";
        $status = true;
    }
    if(isset($ref) && !empty($ref)) {

        $qry = "SELECT COUNT(*) FROM student WHERE sid='".$ref."'";

        $res = $db->count($qry);

        if ($res['status'] == 1 && $res['count'] > 0) {
            if($status == false) {

                if(!isset($state))
                    $state = "";

                if(!isset($city))
                    $city = "";

                $propitc = "";

                if(isset($_FILES["upfiles"]) && !empty($_FILES["upfiles"]["name"])) {
                    $filepath = "../public/";

                    $temp = explode(".", $_FILES["propic"]["name"]);
                    $extension = end($temp);

                    $filename = date('YmdHis') . rand(100, 999) . "." . $extension;

                    $imageTemp = $_FILES["propic"]["tmp_name"];

                    if ($func->compress_image($_FILES["propic"]['tmp_name'], $filepath . $filename) == false) {
                        $status = true;
                        $error['propic'] = 'File is not upload Succefully';
                    } else {
                        $propitc = $filename;
                    }
                }


                $qry = "UPDATE `student` SET `sname`='".$uname."',`email`='".$email."',`mobileno`='".$mobileno."',";

                if($state != "")
                    $qry .= "`state`='".$state."',";
                if($city != "")
                    $qry .= "`city`='".$city."',";
                if($propitc != "")
                    $qry .= "`propic`='".$propitc."',";

                $qry .= "`idatetime`='".getLdate()."' WHERE sid='".$ref."'";

                $res = $db->update($qry);

                if ($res["status"] == 1) {
                    $output['data'] = array('msg'=>"Student updated Successfully.");
                    $output['status'] = 1;
                } else {
                    $error['error'] = $res["msg"];
                }
            }
        } else {
            $error['error'] = "Id is not found.";
        }

    } else {
        $error['error'] = "Id is invalid.";
    }


} else {
    $error['error'] = "Invalid Authentication.";
}


$output['error'] = $error;


echo json_encode($output);

?>
